package manajemenalatmusik;

public class Gamelan extends AlatMusik implements Perawatan {
    public Gamelan(String nama, String asal) {
        super(nama, asal);
    }

    @Override
    public void mainkan() {
        System.out.println(nama + " dimainkan dengan dipukul.");
    }

    @Override
    public void rawat() {
        System.out.println(nama + " dirawat dengan cara disimpan di tempat kering.");
    }
}


