package manajemenalatmusik;

public class Main {
    public static void main(String[] args) {
        AlatMusik gamelan = new Gamelan("Gamelan Jawa", "Jawa Tengah");
        AlatMusik angklung = new Angklung("Angklung", "Jawa Barat");

        gamelan.tampilkanInfo();
        gamelan.tampilkanInfo(true);
        gamelan.mainkan();
        ((Perawatan) gamelan).rawat();

        System.out.println();

        angklung.tampilkanInfo();
        angklung.tampilkanInfo(false);
        angklung.mainkan();
        ((Perawatan) angklung).rawat();
    }
}