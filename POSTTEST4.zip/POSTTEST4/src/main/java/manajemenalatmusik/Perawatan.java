package manajemenalatmusik; 

public interface Perawatan { 
    void rawat(); 
}