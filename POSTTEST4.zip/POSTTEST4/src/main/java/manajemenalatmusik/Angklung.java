package manajemenalatmusik;

public class Angklung extends AlatMusik implements Perawatan {
    public Angklung(String nama, String asal) {
        super(nama, asal);
    }

    @Override
    public void mainkan() {
        System.out.println(nama + " dimainkan dengan digoyangkan.");
    }

    @Override
    public void rawat() {
        System.out.println(nama + " dirawat dengan cara dijemur sesekali agar bambu tidak lembab.");
    }
}