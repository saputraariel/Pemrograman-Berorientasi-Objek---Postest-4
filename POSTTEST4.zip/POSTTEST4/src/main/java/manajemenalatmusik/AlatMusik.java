package manajemenalatmusik;

public abstract class AlatMusik {
    String nama;
    String asal;

    public AlatMusik(String nama, String asal) {
        this.nama = nama;
        this.asal = asal;
    }

    public abstract void mainkan();

    public void tampilkanInfo() {
        System.out.println("Nama: " + nama + ", Asal: " + asal);
    }

    public void tampilkanInfo(boolean detail) {
        if (detail) {
            System.out.println("Alat musik " + nama + " berasal dari " + asal);
        } else {
            tampilkanInfo();
        }
    }
}
